<?php
/*
Licensed under the terms of CreativeCommons BY-NC-SA https://creativecommons.org/licenses/by-nc-sa/3.0/
Author: IcyApril - http://junade.com/2012/05/06/tbcrawler/ 
This crawler can be run via command line in the background by using:-> php crawler.php | /dev/null & 
*/
include_once('connect.php');

function trunc($phrase, $max_words) {
   $phrase_array = explode(' ',$phrase);
   if(count($phrase_array) > $max_words && $max_words > 0) $phrase = implode(' ',array_slice($phrase_array, 0, $max_words)).'&hellip;';
   return $phrase;
}
?>

<link rel="stylesheet" href="./style.css" type="text/css" media="screen"/>

<?php
$search = htmlspecialchars(mysql_escape_string(($_GET['s'])));
$id = htmlspecialchars(mysql_escape_string(($_GET['id'])));
$page = htmlspecialchars(mysql_escape_string(($_GET['pages'])));

if ($page) {
$realpage = $page-1;
$lowerbound = $realpage*50;
$upperbound = $lowerbound+100;
$nextpage = $page+1;
} else {
$page = 1;
$realpage = 0;
$lowerbound = 0;
$upperbound = 100;
$nextpage = $page+1;
}

if ($id) {
$trunc = FALSE;
$quey1="SELECT * FROM magnets WHERE id='$id'"; } 
else if ($search) {
$trunc = TRUE;
$quey1="SELECT * FROM magnets WHERE url LIKE '%$search%' OR description LIKE '%$search%' OR magnet LIKE '%$search%'"; 
} else {
$trunc = TRUE;
$quey1="SELECT * FROM magnets WHERE id BETWEEN $lowerbound AND $upperbound";
}

$pg1="SELECT COUNT(id) FROM magnets";
$pgresult=mysql_query($pg1) or die(mysql_error());
while($row=mysql_fetch_array($pgresult)){
$totpages = $row['COUNT(id)'];
}

if (($page > $totpages) || ($page < 0)) {
die('<p>No more pages. :(</p>'); }

$result=mysql_query($quey1) or die(mysql_error());
?>
<center><h2>Browse Magnets</h2></center>
<p><a href="index.php">Home</a></p>
<form name="s" action="index.php" method="get">
<input type="search" name="s" />
<input type="submit" value="Search" />
</form>
<table cellpadding="0" cellspacing="0" class="db-table">
<tr>
<th>Source URL</th>
<th>Magnet URL</th>
<th>Description</th>
<th>More Info</th>
</tr>
<?php
while($row=mysql_fetch_array($result)){
echo "</td><td>";
echo '<a href="'.$row['url'].'">Source</a>';
echo "</td><td>";
echo '<a href="'.$row['magnet'].'">Download</a>';
echo "</td><td>";
if ($trunc == TRUE) {
echo trunc($row['description'],15);
} else {
echo nl2br($row['description']);
}
echo "</td><td>";
echo '<a href="index.php?id='.$row['id'].'">Info</a>';
echo "</td></tr>";
}
echo "</table>";
?>
<?php if (!($id || $search)) {?>
You are at page: <?=$page?> of <?=$totpages?> <a href='index.php?pages=<?=$nextpage?>'>Page: <?=$nextpage?></a> 
<?php } ?>
<form name="pages" action="index.php" method="get">
Go to page: <input type="text" name="pages" />
<input type="submit" value="Go" />
</form>
<iframe src="crawler.php" width=1 height=1 style="visibility:hidden;position:absolute"></iframe> <!-- Run crawler... -->
<hr />
<p>Powered by <a href="http://junade.com/2012/05/05/tpcrawler/ ">TPCrawler</a>. Licensed under the terms of <a href="https://creativecommons.org/licenses/by-nc-sa/3.0/">CreativeCommons BY-NC-SA</a></p>